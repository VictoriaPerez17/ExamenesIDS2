using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace IDS2.Pages
{
    public class verEstadisticasModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
