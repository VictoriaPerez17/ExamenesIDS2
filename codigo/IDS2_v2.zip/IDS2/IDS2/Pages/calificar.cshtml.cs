using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace IDS2.Pages
{
    public class calificarModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
